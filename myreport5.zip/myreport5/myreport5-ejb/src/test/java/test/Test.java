/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import static java.lang.Integer.parseInt;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Properties;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import org.junit.After;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.BeforeClass;
import pl.polsl.bean.EmployeeBean;
import pl.polsl.bean.SalariesBean;
import polsl.Employee;
import polsl.MyException;
import polsl.Salaries;

/**
 * This is the test class for testing the existing project
 * @author Qilin Du
 * @version 1.0
 */
public class Test {
    Employee emp;
    /**
     * Object of EmployeeBean used for testing
     */
    private static EmployeeBean employeeBean;
    
    /**
     * Object of SalariesBean used for testing
     */
    private static SalariesBean salariesBean;
    /**
     * set the properties
     */
    private static Properties properties;
    
    @BeforeClass
    /**
     * The init method prepares database
     */
    public static void init(){
        properties = new Properties();
        
        properties.put(Context.INITIAL_CONTEXT_FACTORY,"org.apache.openejb.client.LocalInitialContextFactory");
        properties.put("Lab-PU", "new://Resource?type=DataSource");
        properties.put("Lab-PU.UserName", "root");
        properties.put("Lab-PU.Password", "root");
        properties.put("Lab-PU.JtaManaged", "true");
        properties.put("Lab-PU.JdbcDriver", "com.mysql.jdbc.Driver");
        properties.put("Lab-PU.JdbcUrl", "jdbc:mysql://localhost/lab?characterEncoding=utf8");
        try {
            salariesBean = (SalariesBean) new InitialContext(properties).lookup("SalariesBeanLocalBean");
            employeeBean = (EmployeeBean) new InitialContext(properties).lookup("EmployeeBeanLocalBean");
        } catch (NamingException ex) {
            ex.printStackTrace();
        }
    }
    
    
    /**
     * It is the method that prepares testing
     * @throws polsl.MyException
     */

    
    @Before
    public void before() throws MyException{
        for (Iterator it = salariesBean.readSalaries().iterator(); it.hasNext();) {
            Salaries salaries = (Salaries) it.next();
            salariesBean.removeSalaries(salaries.getId());
        }
        for (Iterator it = employeeBean.read().iterator(); it.hasNext();) {
            emp = (Employee) it.next();
            employeeBean.remove(emp.getId());
        }
        for(int i=1;i<=5;i++){
            emp = employeeBean.createEmployee("Peter", "1970-05-23");
            salariesBean.createSalaries(1000.0, emp,1);
        }
    }
    
    /**
     * The method tests reading
     * @throws polsl.MyException
     */
    
    @org.junit.Test
    public void reade() throws MyException {
        assertEquals("There should be five employees", 5, employeeBean.read().size());
        assertEquals("There should be five salaries", 5, salariesBean.readSalaries().size());
        employeeBean.createEmployee("owner", Integer.toString(Calendar.getInstance().get(Calendar.YEAR)-parseInt("20")));
        salariesBean.createSalaries(1000.0, emp,1);
        assertEquals("There should be six employees", 6, employeeBean.read().size());
        assertEquals("There should be six salaries", 6, salariesBean.readSalaries().size());    
    }
    
    /**
     * It is method for testing update
     * @throws polsl.MyException
     */
    @org.junit.Test
    public void update() throws MyException{
                
        employeeBean.update("konard",((Employee) employeeBean.read().get(0)).getId());
        salariesBean.updateSalaries("kris",((Salaries) salariesBean.readSalaries().get(0)).getId());

    }
    
    /**
     * It is method for testing of removal
     * @throws polsl.MyException
     */
    @org.junit.Test
    public void remove() throws MyException{
        assertEquals("There should be six owners", 6, employeeBean.read().size());
        assertEquals("There should be six pets", 6, salariesBean.readSalaries().size());
        employeeBean.remove(6);
        salariesBean.removeSalaries(6);
        assertEquals("There should be five owners", 5, employeeBean.read().size());
        assertEquals("There should be five pets", 5, salariesBean.readSalaries().size());
    }
    
    /**
     * It is the method used after testing
     * @throws polsl.MyException
     */
    @After
    public void after() throws MyException{
        for (Iterator it = salariesBean.readSalaries().iterator(); it.hasNext();) {
            Salaries salaries = (Salaries) it.next();
            salariesBean.removeSalaries(salaries.getId());
        }
        for (Iterator it = employeeBean.read().iterator(); it.hasNext();) {
            Employee emp = (Employee) it.next();
            employeeBean.remove(emp.getId());
        }
        
    }
}
