package pl.polsl.bean;

import polsl.MyException;
import polsl.Employee;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * class EmployeeBean,local bean, to perform crud operations
 * @author Qilin Du
 * @version 2.0
 */
@Stateless
@LocalBean
public class EmployeeBean  {
    /**
     * 
     */
    @PersistenceContext
    private EntityManager em;

    
    /**
    * creating new employees in the database
    * @param name which is the name of employee
    * @param date date
    * @throws polsl.MyException when input the wrong data
    */
    public Employee createEmployee(String name,String date) throws MyException {
        try{
            Employee employee=new Employee(name,new Date());
            employee.setBirthDate(new SimpleDateFormat("yyyy").parse(date));
            em.persist(employee);
            return employee;
        }
       catch(NullPointerException e){
           throw new MyException(e.getMessage());
       }catch (ParseException ex) {  
            throw new MyException("Incorrect date, the correct date format in yyyy");
        }
    }
   /**
     * This function is used to read all employees
     * 
     * @return it displays all the results
     */
    
    public List read(){
        return em.createNamedQuery("Employee.findAll").getResultList();
    }
    
   /**
     * update the employee
     * 
     * @param name of the employee
     * @param empid of the employee
     * @throws MyException throws when there is no employee under the given ID
     */
    public void update(String name,int empid)throws MyException{
        try{
            Employee employee = em.find(Employee.class, empid);
            if(employee == null) {
                throw new MyException("No employee under this ID");
            }
            employee.setName(name);
            em.merge(employee);
        }catch (NullPointerException e){
            throw new MyException(e.getMessage());
        } 
    }
    
    /**
     * This function is used to delete an employee
     * 
     * @param empid id of the employee
     * @throws MyException throws when there is no employee for that id
     */
    
    public void remove(int empid) throws MyException{
         try{
             Employee employee=em.find(Employee.class, empid);
             if(employee==null){
                 throw new MyException("No employee under this ID");
             }
             em.remove(employee);
         }catch (NullPointerException e){
            throw new MyException(e.getMessage());
        }
    }
}
