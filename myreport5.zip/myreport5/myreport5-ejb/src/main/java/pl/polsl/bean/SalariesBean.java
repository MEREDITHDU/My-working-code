/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pl.polsl.bean;


import java.util.List;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import polsl.Employee;
import polsl.MyException;
import polsl.Salaries;

/**
 * SalariesBean class, to perform crud operations
 * @author Qilin Du
 * @version 2.0
 */
@Stateless
@LocalBean
public class SalariesBean  {
    @PersistenceContext
    private EntityManager em;

    
    /**
     * This function is used to create a new salary
     * 
     * @param value it is the salaries of the employee
     * @param emp it is the object of employee
     * @param empid it is the id of employee
     * @throws polsl.MyException throws when date cannot be parsed correctly 
     */
    
    public void createSalaries(Double value, Employee emp,int empid) throws MyException {
        try{
            Employee employee = em.find(Employee.class,emp.getId());
            if(employee == null) {
                throw new MyException("Missing employee");
            }
            Salaries salaries = new Salaries();
            salaries.setAmount(value);
            salaries.setEmp(employee);
            em.persist(salaries);
            
        }catch (NullPointerException e){
            throw new MyException(e.getMessage());
        } 
    }
    
     /**
     * This function is used to update the salaries
     * 
     * @param value it is the salary of employee
     * @param empid it is id of the employee
     * @throws polsl.MyException throws when there is no employee under the given ID
     */
    
    public void updateSalaries(double value, int empid) throws MyException{
        try{
            Salaries salaries = em.find(Salaries.class, empid);
            if(salaries == null) {
                throw new MyException("No salaries under this ID");
            }
            salaries.setAmount(value);
            em.merge(salaries);
        }catch (NullPointerException e){
            throw new MyException(e.getMessage());
        }  
    }
    
    /**
     * This function is used to read all salaries
     * 
     * @return it displays all the results
     */
    
    public List readSalaries(){
        return em.createNamedQuery("Salaries.findAll").getResultList();
    }
    
    /**
     * This function is used to delete a salary
     * 
     * @param empid it is id of the employee
     * @throws polsl.MyException throws when there is no employee under the given ID
     */
    
    public void removeSalaries(int empid) throws MyException{
        try{
            Salaries salaries = em.find(Salaries.class, empid);
            if(salaries == null) {
                throw new MyException("No salaries under this ID");
            }
            em.remove(salaries);
        }catch (NullPointerException e){
            throw new MyException(e.getMessage());
        } 
    
    }

    public void updateSalaries(String value, int parseInt) {
        
    }
}
