package polsl;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * class Employee, define the employee table
 * @author qilin du
 * @version 2.0
 */
@Entity
@Table(name="employee")
@NamedQueries({@NamedQuery(name="Employee.findAll",query="Select e from Employee e"),
@NamedQuery(name="Employee.findByName",query="Select e from Employee e where e.name like :xyz order by e.id desc")
 })
 
public class Employee implements Serializable{
    
    /**
     * primary key, ID of the employee
     */    
    @Id
    @Column(name = "emp_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    /**
     * primary key, name of the employee
     */
    @Column(name = "ownerName",length = 50)
    private String name;
    /**
     * primary key,birth day of the employee
     */ 
    @Column(name = "birthDate")
    @Temporal(TemporalType.DATE)
    private Date birthDate;
   
    /**
     * one to many mapping
     */
    @OneToMany(mappedBy="emp",cascade=CascadeType.REMOVE)
    private List<Salaries> salary=new ArrayList<>();
    
    /** equals method, to avoid same object
    * @param obj another object used for comparison
    * @return true or false
    */
    @Override
    public boolean equals(Object obj) {
         if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Employee other = (Employee) obj;
        if(!Objects.equals(this.id, other.id))
            return false;
        if(this.name==null){
            if(other.name!=null)
                return false;
        }
        else if(this.name.equals(other.name))
            return false;
        return Objects.equals(this.id,other.id);
    }
    
    /**
    * override function
    * @return hash
    */
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 29 * hash + Objects.hashCode(this.id);
        return hash;
    }
    
    /**
     * getId method
     * @return id of employee
     */
    public Integer getId() {
        return id;
    }

    /**
     * setId method
     * @param id of employee
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * getName method, obtain name of employee
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * setName method,set name of employee
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * getBirthDate method
     * @return birthDate of employee
     */
    public Date getBirthDate() {
        return birthDate;
    }

    /**
     * srtBirthDtae method,set birth date of employee
     * @param birthDate of employee
     */
    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }
    
    /*
    * Constructor Employee
    */

    public Employee() {
    }
    
    /**
     * Constructor Employee
     * @param name of employees
     * @param birthDate of employees
     */
    public Employee(String name,Date birthDate){
        this.name = name;
        this.birthDate = birthDate;
    }
    
    /**
     * Override function 
     * @return name, birthdate
     */
     @Override
     public String toString(){
         return new StringBuilder().append(id).append(",").
                 append(name).
                 append(new SimpleDateFormat("dd/MM/yyyy").format(birthDate)).toString();
     }
}
