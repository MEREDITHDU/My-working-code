package polsl;

import polsl.Employee;
import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * class Salaries, define the table of emp_salaries.
 * @author qilin du
 * @version 2.0
 */
@Entity
@Table(name="emp_salaries")
@NamedQueries({@NamedQuery(name="Salaries.findAll",query="Select s from Salaries s")
//@NamedQuery(name="Salaries.findByName",query="Select s from Salaries s where s.name like :xyz order by s.id desc")
 })

public class Salaries implements Serializable{
    /**
     * Primary key column, id of employees
     */
    @Id
    @Column(name="emp_id")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;
    /*
    * primary key, column name anount
    */
    @Column(name="amount")
    private double amount;
    /*
    * table relation type many to one, foreign key employee_id
    */
    @ManyToOne(optional=false)
    @JoinColumn(name="employee_id")
    private Employee emp;

    /*
    * Constructor Salaries
    */

    public Salaries() {
    }
    
    /**
     * Constructor Salaries
     * @param id of employees
     * @param amount of salaries
     * @param emp employee
     */

    public Salaries(Integer id, double amount, Employee emp) {
        this.id = id;
        this.amount = amount;
        this.emp = emp;
    }
    
    
    /**
     * getId method
     * @return id of employee
     */
    public Integer getId() {
        return id;
    }

    /**
     * setId method
     * @param id primary key
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * getAmount method, the amount of salaries
     * @return salary amount
     */
    public double getAmount() {
        return amount;
    }

    /**
     * setAmount method, set amount of salaries
     * @param amount salary amount
     */
    public void setAmount(double amount) {
        this.amount = amount;
    }

    /**
     * get the properties of employees
     * @return employee employee
     */
    public Employee getEmp() {
        return emp;
    }

    /**
     * set employee info
     * @param emp employee
     */
    public void setEmp(Employee emp) {
        this.emp = emp;
    }

    /**
    * Override function,equals method,to avoid same object
    * @param obj for comparison
    * @return true or false
    */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
                return true;
            }
        if (obj == null) {
                return false;
            }
        if (getClass() != obj.getClass()) {
                return false;
            }
        final Salaries other = (Salaries) obj;
        return Objects.equals(this.id, other.id);
    }

    /**
    * override function
    * @return hash
    */
    @Override
    public int hashCode() {
        int hash = 5;
            hash = 89 * hash + Objects.hashCode(this.id);
            return hash;
    }
   
    /**
     * This function is an override
     * 
     * @return data of the salaries
     */
    
    @Override
    public String toString(){
        
    return new StringBuilder().append(id).toString();
    
    }
}
