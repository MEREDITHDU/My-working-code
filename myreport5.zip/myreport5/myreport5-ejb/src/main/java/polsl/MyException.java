/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polsl;

/**
 * This class is the exception class which will be used in program
 * @author Qilin Du
 * @version 2.0
 */
public class MyException extends Exception{
    /** Constructor without parametric
     * 
     */
    public MyException() {
    }

    /** Constructor
     *	@param message display message
     */
    public MyException(String message) {
        super(message);
    }
}
