/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pl.polsl;

import pl.polsl.bean.EmployeeBean;
import pl.polsl.bean.SalariesBean;
import java.io.Serializable;
import static java.lang.Integer.parseInt;
import java.util.Calendar;
import java.util.List;
import javax.annotation.ManagedBean;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import polsl.Employee;
import polsl.MyException;
import polsl.Salaries;

/**
 * This class is the controller class which has multiple methods 
 * to control the sessions
 * @author Qilin Du
 * @version 1.0
 */
@ManagedBean
@SessionScoped
public class myController implements Serializable {
    Employee emp;
    /**
     * EJB for handling employees
     */
    @EJB
    private EmployeeBean employeeBean;
    /**
     * EJB for handling salaries
     */
    @EJB
    private SalariesBean salariesBean;
    
    private String name;
    private int id;
    private String age;

    /**
     * name getter
     * @return name the name of employee
     */
    public String getName() {
        return name;
    }
    
    /**
     * name setter
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }
    
    /**
     * id getter
     * @return id the id of employee
     */
    
    public int getId() {
        return id;
    }
    
    /**
     * id setter
     * @param id
     */
    
    public void setId(int id) {
        this.id = id;
    }
    
    /**
     * age getter
     * @return age the age of employee
     */
    
    public String getAge() {
        return age;
    }
    
    /**
     * age setter
     * @param age
     */
    
    public void setAge(String age) {
        this.age = age;
    }
    
    /**
     * this function creates the salary
     * @throws polsl.MyException throws an exception if invalid id
     */
    
    public void createSalaries() throws MyException {
        salariesBean.createSalaries(1000.0,emp,5);
    }
    
    /**
     * this function creates the employees
     * @throws polsl.MyException throws an exception if invalid id
     */
    
    public void createEmployee() throws MyException {
       employeeBean.createEmployee(name, Integer.toString(Calendar.getInstance().get(Calendar.YEAR)-parseInt(age))); 
    }
    
        /**
     * this function reads Employees
     * @return list of employees
     */
    
    public List<Employee> readEmployee(){
        return employeeBean.read();
    }
    
    /**
     * this function reads salaries
     * @return list of salaries
     */
    
     public List<Salaries> readSalaries(){
        return salariesBean.readSalaries();
    }
    
    /**
     * this function updates the salary
     * @throws polsl.MyException throws an exception if invalid id
     */
    
    public void updateSalary() throws MyException {
        salariesBean.updateSalaries(name,id);
    }
    
    /**
     * this function updates the employee
     * @throws polsl.MyException throws an exception if invalid id
     */
    
    public void updateEmployee() throws MyException {
       employeeBean.update(name,id);
    }
    
    /**
     * this function removes the salary
     * @throws polsl.MyException throws an exception if invalid id
     */
    
    public void removeSalary() throws MyException {
        salariesBean.removeSalaries(id);
    }
    
    /**
     * this function removes the employee
     * @throws polsl.MyException throws an exception if invalid id
     */
    
    public void removeEmployee() throws MyException {
       employeeBean.remove(id);
    }
    
    @PostConstruct
    protected void init(){
        System.out.println("Init");
    }
    
    @PreDestroy
    protected void reset(){
        System.out.println("Reset");
    }
}
